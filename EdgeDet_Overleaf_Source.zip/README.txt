EDGEDET OVERLEAF SOURCE

1. In Overleaf, choose New Project -> Upload Project.
2. Upload EdgeDet_Overleaf_Source.zip.
3. main.tex is already the root document.
4. In Menu -> Settings, select pdfLaTeX and Normal compile mode.
5. Click Recompile.

The report prose, tables, captions, references, and chapter files remain
editable. The nine complex TikZ/PGFPlots diagrams are included from
figures-precompiled/tikz-figures-source.pdf to stay within the free compile-time
limit. Their editable vector source is retained as
figures-precompiled/tikz-figures-source.tex.

The hbox messages shown by Overleaf are spacing warnings, not compile errors.
